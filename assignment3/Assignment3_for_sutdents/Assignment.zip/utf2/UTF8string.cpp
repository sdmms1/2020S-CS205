#include "utf8.h"
#include "UTF8string.hpp"

UTF8string::UTF8string(string str) {
    this->str = std::move(str);
}

UTF8string::UTF8string(char *ch) {
    this->str = ch;
}

int UTF8string::length() {
    return utf8_charlen((unsigned char *) str.c_str());
}

int UTF8string::bytes() {
    return utf8_charpos_to_bytes((unsigned char *) this->str.c_str(), this->length());
}

int UTF8string::find(string substr) {
    unsigned char *p = utf8_search(reinterpret_cast<const unsigned char *>(str.c_str()),
                                   reinterpret_cast<const unsigned char *>(substr.c_str()));
    return p ? utf8_charlen((unsigned char *) str.c_str()) - utf8_charlen(p) : -1;
}

void UTF8string::replace(UTF8string to_remove, UTF8string replacement) {
    int index = this->find(to_remove.str);
    if (index != -1) {
        str.replace(str.find(to_remove.str), to_remove.str.length(), replacement.str);
    }
}

UTF8string UTF8string::operator+(const UTF8string &s) const {
    return UTF8string(str + s.str);
}

UTF8string UTF8string::operator+=(const UTF8string &s) {
    str.append(s.str);
    return *this;
}

UTF8string UTF8string::operator*(const int &times) const {
    UTF8string st(str);
    UTF8string res(str);
    for (int i = 1; i < times; ++i) {
        res = res + st;
    }
    return res;
}

UTF8string operator*(int times, const UTF8string &s) {
    UTF8string st(s.str);
    UTF8string res(s.str);
    for (int i = 1; i < times; ++i) {
        res = res + st;
    }
    return res;
}

UTF8string operator!(UTF8string s) {
    string rev;
    auto *p = (unsigned char *) s.str.c_str();
    int i = s.length();
    while (i >= 0) {
        int bytes = utf8_charpos_to_bytes(p, i);
        rev.append(s.str, bytes, isutf8(p + bytes));
        i--;
    }
    return UTF8string(rev);
}

ostream &operator<<(ostream &os, const UTF8string &s) {
    os << s.str;
    return os;
}
