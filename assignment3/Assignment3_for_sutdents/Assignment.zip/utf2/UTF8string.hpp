#include <cstring>
#include <iostream>

using namespace std;

class UTF8string {
    friend UTF8string operator*(int, const UTF8string &);

    friend UTF8string operator!(UTF8string);

    friend ostream &operator<<(ostream &, const UTF8string &);

private:
    string str;

public:

    UTF8string(string);

    UTF8string(char *);

    int length();

    int bytes();

    int find(string);

    void replace(UTF8string, UTF8string);

    UTF8string operator+(const UTF8string &) const;

    UTF8string operator+=(const UTF8string &);

    UTF8string operator*(const int &) const;

};